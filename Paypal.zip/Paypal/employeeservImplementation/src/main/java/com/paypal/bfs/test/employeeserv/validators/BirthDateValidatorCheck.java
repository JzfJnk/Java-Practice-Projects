package com.paypal.bfs.test.employeeserv.validators;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;

public class BirthDateValidatorCheck implements ConstraintValidator<BirthDateValidator, String> {
    DateTimeFormatter dateFormatter = DateTimeFormatter.ISO_LOCAL_DATE;

    @Override
    public boolean isValid(String dateString, ConstraintValidatorContext constraintValidatorContext) {
        try {
            LocalDate.parse(dateString, this.dateFormatter);
        } catch (DateTimeParseException e) {
            return false;
        }
        return true;
    }
}
