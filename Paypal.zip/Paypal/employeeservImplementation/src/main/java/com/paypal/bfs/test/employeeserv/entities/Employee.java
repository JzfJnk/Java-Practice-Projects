package com.paypal.bfs.test.employeeserv.entities;

import com.paypal.bfs.test.employeeserv.validators.BirthDateValidator;
import lombok.*;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.validation.Valid;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Pattern;
import java.io.Serializable;

@Entity
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@ToString
@EqualsAndHashCode
public class Employee implements Serializable {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Integer id;
    @NotBlank(message = "Missing first name.")
    private String firstName;
    @NotBlank(message = "Missing last name.")
    private String lastName;
    @NotBlank(message = "Missing date of birth.")
    @BirthDateValidator
    private String dateOfBirth;
    @Valid
    private Address address;

    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    @ToString
    public static class Address implements Serializable{
        @NotBlank(message = "Missing line1.")
        private String line1;
        private String line2;
        @NotBlank(message = "Missing city.")
        private String city;
        @NotBlank(message = "Missing state.")
        private String state;
        @NotBlank(message = "Missing zip-code.")
        @Pattern(regexp = "^[0-9]{5}$")
        private String zipCode;
        @NotBlank(message = "Missing country.")
        private String country;
    }
}
