package com.paypal.bfs.test.employeeserv.controller;

import com.paypal.bfs.test.employeeserv.entities.Employee;
import com.paypal.bfs.test.employeeserv.service.EmployeeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;

@RestController
@RequestMapping("/employees")
public class EmployeeController {
    @Autowired
    EmployeeService employeeService;

    @GetMapping("/retrieve/{id}")
    public ResponseEntity<Employee> getEmployeeById(@PathVariable("id") String id) {
        Employee emp =  employeeService.getEmployeeById(Integer.valueOf(id));

        return new ResponseEntity<>(emp, HttpStatus.OK);
    }

    @PostMapping("/create")
    ResponseEntity<Employee> saveEmployee(@Valid @RequestBody Employee employee) {
       return new ResponseEntity<>(employeeService.save(employee), HttpStatus.CREATED);
    }
}
