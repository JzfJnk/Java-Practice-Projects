package com.paypal.bfs.test.employeeserv.service;

import com.paypal.bfs.test.employeeserv.entities.Employee;
import com.paypal.bfs.test.employeeserv.repositories.EmployeeRepository;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.*;

@SpringBootTest
class EmployeeServiceTest {

    @Mock
    EmployeeRepository employeeRepository;

    @InjectMocks
    EmployeeService employeeService = new EmployeeService();


    @Test
    void getEmployeeById() {
        Integer id = 1;
        Employee employeeWithId = buildEmployeeWithGeneratedId(id);

        when(employeeRepository.findById(id)).thenReturn(Optional.of(employeeWithId));

        Employee employee = employeeService.getEmployeeById(id);

        verify(employeeRepository, times(1)).findById(id);
        assertEquals(employeeWithId, employee);
    }

    @Test
    void getAllEmployees() {
        List<Employee> employees =  IntStream.of(1,2,3).boxed()
                .map(this::buildEmployeeWithGeneratedId)
                .collect(Collectors.toList());

        when(employeeRepository.findAll()).thenReturn(employees);

        List<Employee> allEmployees = employeeService.getAllEmployees();

        verify(employeeRepository, times(1)).findAll();
        assertEquals(employees.size(),allEmployees.size());

    }

    @Test
    void save() {
        Employee employeeToBeInserted = buildEmployeeWithoutId();
        Employee employeeWithId = buildEmployeeWithGeneratedId(1);

        when(employeeRepository.save(employeeToBeInserted)).thenReturn(employeeWithId);

        Employee employeeInserted = employeeService.save(employeeToBeInserted);

        verify(employeeRepository, times(1)).save(employeeToBeInserted);
        assertEquals(employeeWithId, employeeInserted);
    }

    private Employee buildEmployeeWithoutId() {
        return Employee.builder()
                .firstName("Joe")
                .lastName("Brown")
                .dateOfBirth("1988-01-30")
                .address(Employee.Address.builder()
                        .line1("10 Main St")
                        .line2("Apt.1")
                        .city("New York City")
                        .state("NY")
                        .zipCode("10001")
                        .country("USA")
                        .build())
                .build();
    }

    private Employee buildEmployeeWithGeneratedId(Integer id) {
        Employee emp = buildEmployeeWithoutId();
        emp.setId(id);
        return emp;
    }
}