package com.paypal.bfs.test.employeeserv.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.paypal.bfs.test.employeeserv.entities.Employee;
import com.paypal.bfs.test.employeeserv.exceptions.CustomExceptionHandler;
import com.paypal.bfs.test.employeeserv.repositories.EmployeeRepository;
import com.paypal.bfs.test.employeeserv.service.EmployeeService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;

import java.util.Optional;

@SpringBootTest
@AutoConfigureMockMvc
public class EmployeeControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private ObjectMapper objectMapper;

    @Autowired
    public EmployeeRepository employeeRepository;

    @Autowired
    private EmployeeService employeeService;

    @Autowired
    private CustomExceptionHandler customExceptionHandler;

    @Test
    void whenValidInput_thenReturns201() throws Exception {

        Employee employee = buildEmployee();

        mockMvc.perform(post("/employees/create")
                .contentType("application/json")
                .content(objectMapper.writeValueAsString(employee)))
                .andExpect(status().isCreated());
    }

    @Test
    void whenEmptyValue_thenReturns400() throws Exception {

        Employee employee = buildEmployee();
        employee.setFirstName("");

        mockMvc.perform(post("/employees/create")
                .contentType("application/json")
                .content(objectMapper.writeValueAsString(employee)))
                .andExpect(status().isBadRequest());
    }

    @Test
    void whenNullValue_thenReturns400() throws Exception {

        Employee employee = buildEmployee();
        employee.setFirstName(null);

        mockMvc.perform(post("/employees/create")
                .contentType("application/json")
                .content(objectMapper.writeValueAsString(employee)))
                .andExpect(status().isBadRequest());
    }

    @Test
    void whenBadBirthDateValue_thenReturns400() throws Exception {

        Employee employee = buildEmployee();
        employee.setDateOfBirth("2001-02-29");

        mockMvc.perform(post("/employees/create")
                .contentType("application/json")
                .content(objectMapper.writeValueAsString(employee)))
                .andExpect(status().isBadRequest());
    }

    @Test
    void whenGetMissingEmployee_thenReturns404() throws Exception {
        Integer id = 999;

        mockMvc.perform(get("/employees/retrieve/{id}", id)
                .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isNotFound());
    }

    @Test
    void whenGetExistingEmployee_thenReturns200() throws Exception {
        Integer id = 1;
        Employee employee = buildEmployee();
        employee.setId(id);

        employeeService.save(employee);

        mockMvc.perform(get("/employees/retrieve/{id}", id)
                .accept(MediaType.APPLICATION_JSON))
                .andDo(print())
                .andExpect(status().isOk())
                .andExpect(MockMvcResultMatchers.jsonPath("$.id").value(id))
                .andExpect(MockMvcResultMatchers.jsonPath("$.firstName").value("Joe"))
                .andExpect(MockMvcResultMatchers.jsonPath("$.address.zipCode").value("10001"));
    }

    private Employee buildEmployee() {
        return Employee.builder()
                .firstName("Joe")
                .lastName("Brown")
                .dateOfBirth("1988-01-30")
                .address(Employee.Address.builder()
                        .line1("10 Main St")
                        .line2("Apt.1")
                        .city("New York City")
                        .state("NY")
                        .zipCode("10001")
                        .country("USA")
                        .build())
                .build();
    }
}
